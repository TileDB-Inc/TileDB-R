
This data set was created uusing TileDB 2.3.4 and version 0.18.0 of the R package via

```r
library(tiledb)

df <- data.frame(key=1:10,
                 val1=c(letters[1:4], NA, letters[6:7], NA, letters[9:10]),
                 val2=LETTERS[1:10])
print(df)
uri <- "min_ex"
fromDataFrame(df, uri, col_index=1)
res <- tiledb_array(uri, return_as="data.frame")[]
print(res)
```
