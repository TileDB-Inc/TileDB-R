
This data set was created uusing TileDB 2.3.4 and version 0.18.0 of the R package via

```r
library(tiledb)

df <- data.frame(key=1:10,
                 val1=c(letters[1:4], NA, letters[6:7], NA, letters[9:10]),
                 val2=LETTERS[1:10])
print(df)
uri <- "legacy_validity"
fromDataFrame(df, uri, col_index=1)

arr <- tiledb_array(uri)
arr <- tiledb_array_open(arr, "WRITE")
invisible(tiledb_put_metadata(arr, "text", "the quick brown fox"))
invisible(tiledb_put_metadata(arr, "data", c(123L, 456L, 789L)))
arr <- tiledb_array_close(arr)
```
